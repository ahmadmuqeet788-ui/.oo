Fonts used by this website (both free, SIL Open Font License):

  Fraunces            weights 600, 800   -> headings, logo, prices
  Plus Jakarta Sans   weights 400, 500, 700 -> body text

Right now the site loads them from Google Fonts (see the <link> in index.html),
so it works with no files here.

To host them yourself (works offline):
  1. Download the .ttf files from https://fonts.google.com/specimen/Fraunces and
     https://fonts.google.com/specimen/Plus+Jakarta+Sans
  2. Convert to .woff2 (e.g. https://cloudconvert.com/ttf-to-woff2)
  3. Save them here with these names:
       Fraunces-SemiBold.woff2
       Fraunces-ExtraBold.woff2
       PlusJakartaSans-Regular.woff2
       PlusJakartaSans-Medium.woff2
       PlusJakartaSans-Bold.woff2
  4. Follow the steps at the top of assets/css/fonts.css
