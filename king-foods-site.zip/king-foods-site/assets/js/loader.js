/* Waits for the storage layer, then loads the main app. */
(window.__kfReady||Promise.resolve()).then(function(){var s=document.createElement("script");s.src="assets/js/app.js";document.body.appendChild(s)});
