/* King Foods - saved prices, photos and details. The Admin panel can generate a new version of this file. */
window.KF_OVR={};
