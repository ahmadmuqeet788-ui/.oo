Put downloadable files here (menu PDF, price list, brochure, etc.) and link to them like:
  <a href="assets/downloads/menu.pdf" download>Download Menu</a>

The current website has no downloadable files, so this folder is empty on purpose.
